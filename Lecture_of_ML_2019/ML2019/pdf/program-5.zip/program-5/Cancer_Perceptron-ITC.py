# パーセプトロン
import numpy
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Perceptron
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import sys

# データのロード
cancer = datasets.load_breast_cancer()

# 種類( malignant, benign )
name = cancer.target_names
label = cancer.target

# 特徴量
feature_names = cancer.feature_names
data = cancer.data

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

#model = Perceptron(eta0=0.1, max_iter=1000, early_stopping=True, validation_fraction=0.1, n_iter_no_change=5) # バージョン0.19.1では対応していない
model = Perceptron(eta0=0.1, max_iter=1000)

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(test_data)
df = model.decision_function(test_data)

print( "\n [ 重みベクトル ]" )
print( model.coef_ )

print( "\n [ 切片 ]" )
print( model.intercept_ )

# 予測値，正解ラベル
print( "\n 予測値，正解ラベル" )
#for i in range(len(test_data)):
for i in range(20):
    print( "{0:12.3f}({1}) : {2}".format( df[i] , predict[i], test_label[i] ) )

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )
