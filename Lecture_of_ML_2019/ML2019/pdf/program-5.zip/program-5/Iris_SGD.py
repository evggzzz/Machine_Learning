# SGD（デルタールール）
import numpy
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.linear_model import SGDClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import sys

# データのロード
iris = datasets.load_iris()

# 種類
name = iris.target_names
label = iris.target

# 特徴量
feature_names = iris.feature_names
data = iris.data

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

# 学習データの平均値，標準偏差の計算
sc = StandardScaler()
sc.fit( train_data )

print( "\n [ 平均値 ]" )
print( sc.mean_ )

print( "\n [ 分散 ]" )
print( sc.var_ )

print( "\n [ 標準偏差 ]" )
print( sc.scale_ ) 

# 標準化
train_data_std = sc.transform(train_data)
test_data_std = sc.transform(test_data)

model = SGDClassifier(eta0=0.1, max_iter=1000, learning_rate='optimal' , loss='hinge' ,
                      early_stopping=True, validation_fraction=0.1, n_iter_no_change=5, penalty='l2')

# 学習
model.fit(train_data_std, train_label)

# 予測
predict = model.predict(test_data_std)
df = model.decision_function(test_data_std)

print( "\n [ 重みベクトル ]" )
print( model.coef_ )

print( "\n [ 切片 ]" )
print( model.intercept_ )

# 予測値，正解ラベル
print( "\n 予測値，正解ラベル" )
for i in range(len(test_data_std)):
    for j in range(len(name)):
        print( "{0:12.3f}".format( df[i][j] ) , end=" " )
    print( "({0}) : {1}".format( predict[i], test_label[i] ) )

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )
