# SVM Classification（Irsiデータセット）
import numpy
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# データのロード
iris = datasets.load_iris()

# 種類
name = iris.target_names
label = iris.target

# 特徴量
feature_names = iris.feature_names
data = iris.data

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

# 線形カーネル
#model = SVC(kernel='linear', probability=True)

# RBFカーネル
#model = SVC(kernel='rbf', C=1, gamma=0.1, probability=True)

# 多項式カーネル
model = SVC(kernel='poly', C=1, gamma=0.1, probability=True)

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(test_data)
predict_proba = model.predict_proba(test_data)

# サポートベクターの表示
print( " [ Support Vector ]" )
for i in range(3):
    print( i , ":" , model.n_support_[i] )
print( model.support_ )

# 予測結果の表示
print( "\n setosa versicolor virginica -> 予測結果 : 正解ラベル" )
for i in range(20):
    print( " {0:5.3f}  {1:5.3f}  {2:5.3f} -> {3:2d} : {4:2d}".format( predict_proba[i][0] , predict_proba[i][1] , predict_proba[i][2] , predict[i] , test_label[i] ) )

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )
