# SVC
import math
import random
import numpy as np
from matplotlib import pyplot as plt
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# データ
data = np.zeros( (200,2) , dtype=np.float32 )

# ラベル
label = np.zeros( 200 , dtype=np.int32 )

# data[0:100] -> クラス1のデータを格納
count = 0
while True:
    x1 = random.uniform(-2,2)
    x2 = random.uniform(-2,2)

    s = math.sqrt( x1*x1+x2*x2 )
    if s < 1.1:
        data[ count ][0] = x1
        data[ count ][1] = x2
        label[ count ] = 0
        count+=1

    if count >= 100:
        break

# data[100:] -> クラス2のデータを格納
while True:
    x1 = random.uniform(-2,2)
    x2 = random.uniform(-2,2)

    s = math.sqrt( x1*x1+x2*x2 )
    if s > 0.9:
        data[ count ][0] = x1
        data[ count ][1] = x2
        label[ count ] = 1
        count+=1

    if count >= 200:
        break
    
work = data.transpose(1,0)

# 散布図の描画
fig = plt.figure()
plt.scatter( work[0][0:100] , work[1][0:100] , c="red" )
plt.scatter( work[0][100:] , work[1][100:] , c="blue" )
plt.xlabel("x")
plt.ylabel("y")
fig.savefig("data.png")
