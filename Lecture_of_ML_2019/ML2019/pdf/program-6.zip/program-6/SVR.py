# SVR（メキシカンハット関数）
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import matplotlib.pyplot as plt

# メキシカンハット関数
data = np.sort(np.random.uniform(-4, 4, 200))
label = ( 1 - data*data ) * np.exp( -0.5 * data * data ) + 0.1*np.random.normal(size=len(data))

data = data.reshape( (len(data),1) )

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

# RBFカーネル
model = SVR(kernel='rbf', C=10000, gamma=0.1, epsilon=0.1)

# 学習
model.fit(train_data, train_label)

# 予測（テストデータ）
predict = model.predict(test_data)

# R2を求める
train_score = model.score(train_data, train_label)
test_score = model.score(test_data, test_label)

print( "\n [ R2 ]" )
print( " 学習データ  : {0:7.5f}".format( train_score ) )
print( " テストデータ: {0:7.5f}".format( test_score ) )

# 散布図の描画
fig = plt.figure()
plt.scatter( test_data , predict , c="red" , label="predict" )
plt.scatter( test_data , test_label , c="blue" , label="data" )
plt.xlabel("data")
plt.ylabel("label")
plt.legend(loc='upper left')
fig.savefig("result.png")




