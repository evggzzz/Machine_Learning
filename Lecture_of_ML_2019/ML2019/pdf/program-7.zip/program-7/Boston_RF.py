# Random Forest（回帰木）
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from sklearn.ensemble import RandomForestRegressor
import sys
import matplotlib.pyplot as plt

# データのロード
boston = datasets.load_boston()

# 特徴量
feature_names=boston.feature_names

data = boston.data

# 価格
price = boston.target

# 学習データ，テストデータ
train_data, test_data, train_price, test_price = train_test_split(data, price, test_size=0.5, random_state=None)

model = RandomForestRegressor(n_estimators=20, criterion="mse", max_features="sqrt", bootstrap=True, oob_score=True)

# 学習
model.fit(train_data, train_price)

# 予測
predict = model.predict(test_data)

print( "\n [ OOB score ]" )
print( model.oob_score_ )

print( "\n [ 特徴の重要度 ]" )
for i in range(len(feature_names)):
    print( " {0:25s} : {1:7.5f}".format( feature_names[i] , model.feature_importances_[i] ) )

# R2を求める
train_score = model.score(train_data, train_price)
test_score = model.score(test_data, test_price)

print( "\n [ R2 ]" )
print( " 学習データ  : {0:7.5f}".format( train_score ) )
print( " テストデータ: {0:7.5f}".format( test_score ) )

# 散布図の描画
fig = plt.figure()
plt.scatter( test_price , predict )
plt.xlabel("Correct")
plt.ylabel("Predict")
fig.savefig("result.png")
