# Bagging
import sys
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# 識別関数（弱分類器）のimport
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn import tree

# バギングのimport
from sklearn.ensemble import BaggingClassifier

# データのロード
cancer = datasets.load_breast_cancer()

# 特徴量
feature_names=cancer.feature_names

data = cancer.data

# 目的変数( malignant, benign )
name = cancer.target_names

label = cancer.target

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

print( '\n [ 弱分類器の選択 ]' )
print( '  ロジスティック回帰 -> 1' )
print( '  k近傍法            -> 2' )
print( '  決定木             -> 3' )
ans = int( input( ' > ' ) )

# ロジスティック回帰
if ans == 1:
    wc = LogisticRegression()
    
# k近傍法   
elif ans == 2:
    wc = KNeighborsClassifier()
    
# 決定木（ランダムフォレスト）
elif ans == 3:
    wc = tree.DecisionTreeClassifier(max_depth=3)

# バギング
model = BaggingClassifier(base_estimator=wc, bootstrap=True, n_estimators=10, max_samples=1.0, max_features=0.5, oob_score=True)
       
# 学習
model.fit(train_data, train_label)

print( "\n [ ブートストラップ ]" )
print( " [ 0番目の弱分類器でサンプリングしたデータ ]" )
print( model.estimators_samples_[0] )

print( "\n [ OOBデータの割合 ]" )
for i in range( model.n_estimators ):
    print( i , ":" , 1 - np.count_nonzero( model.estimators_samples_[i] ) / len( model.estimators_samples_[i] ) )

# 使用した特徴
print( "\n [ 選択された特徴量 ]" )
for i in range( model.n_estimators ):
    print( i , ":" , model.estimators_features_[i] )

# 予測
predict = model.predict(test_data)

print( "\n [ OOB score ]" )
print( model.oob_score_ )

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )


