# Random Forest
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from sklearn.ensemble import RandomForestClassifier

# データのロード
cancer = datasets.load_breast_cancer()

# 特徴量
feature_names=cancer.feature_names

data = cancer.data

# 目的変数( malignant, benign )
name = cancer.target_names

label = cancer.target

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

model = RandomForestClassifier(n_estimators=10, criterion="gini", max_features="sqrt", bootstrap=True, oob_score=True)

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(test_data)

print( "\n [ OOB score ]" )
print( model.oob_score_ )

print( "\n [ 特徴の重要度 ]" )
for i in range(len(feature_names)):
    print( " {0:25s} : {1:7.5f}".format( feature_names[i] , model.feature_importances_[i] ) )

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )
