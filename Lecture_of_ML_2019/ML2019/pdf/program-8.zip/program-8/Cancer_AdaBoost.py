# AdaBoost
import numpy as np
from sklearn import datasets
from sklearn.ensemble import AdaBoostClassifier
from sklearn import tree
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import sys

# データのロード
cancer = datasets.load_breast_cancer()

# 種類( malignant, benign )
name = cancer.target_names
label = cancer.target

# 特徴量
feature_names = cancer.feature_names
data = cancer.data

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

# 弱分類器：決定木（default）
model = AdaBoostClassifier(base_estimator=tree.DecisionTreeClassifier(max_depth=1),n_estimators=5)

# 弱分類器：ベイズ決定則の場合
#wc = GaussianNB()
#model = AdaBoostClassifier(base_estimator=wc,n_estimators=5)

# 学習
model.fit(train_data, train_label)

# 重みの表示
print( "\n [ 重み ]" )
for i in range(model.n_estimators):
    print( "{0} : {1:6.4f}".format( i , model.estimator_weights_[i] ) )

# 最終予測結果
predict = model.predict( test_data )

# 弱分類器の予測確率
predict_wc = model.staged_predict_proba( test_data )

result = np.zeros( (model.n_estimators,len(test_label),2) )
for i , x in enumerate(predict_wc):
    result[i] = x

print( "\n [ 予測結果 ]" )
#for i in range(len(test_label)):
for i in range(10):
    F = np.zeros( 2 )
    for j in range(model.n_estimators):
        print( "{} : ".format( j ) , end="" )
        for k in range(2):
            F[ k ] += model.estimator_weights_[j] * result[j][i][k] 
            print( "{0:6.4f} ".format( result[j][i][k] ) , end="")
        print()
    print( " ------------ " )
    print( " {0:6.4f} {1:6.4f} -> {2} [ {3} ]\n".format( F[0] , F[1] , np.argmax( F ) , test_label[i] ) )

# 予測
predict = model.predict(test_data)

print( " [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )
