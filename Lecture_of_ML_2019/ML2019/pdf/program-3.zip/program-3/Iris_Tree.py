# Decision Tree（Irisデータセット）
import numpy
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# データのロード
iris = datasets.load_iris()

# 種類( setosa , versicolor , virginica )
name = iris.target_names 

# sepal length ガクの長さ
# sepal width  ガクの幅
# petal length 花弁の長さ
# petal width  花弁の幅
data = iris.data

# setosa:0 , versicolor:1 , virginica:2
label = iris.target

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)
print( test_label )

# 決定木
model = tree.DecisionTreeClassifier(criterion="gini",max_depth=10)

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(test_data)
print( predict )

print( " [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )

# 決定木の視覚化
tree.export_graphviz(model, out_file="tree.dot",feature_names=iris.feature_names,class_names=name,filled=True, rounded=True)


