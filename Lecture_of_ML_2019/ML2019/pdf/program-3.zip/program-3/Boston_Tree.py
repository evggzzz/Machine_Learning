# 回帰木（Bostonデータセット）
import numpy
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import matplotlib.pyplot as plt

# データのロード
boston = datasets.load_boston()

# 特徴量
feature_names = boston.feature_names

# データ
data = boston.data

# 価格
price = boston.target

# 学習データ，テストデータ
train_data, test_data, train_price, test_price = train_test_split(data, price, test_size=0.5, random_state=None)

# 回帰木
model = tree.DecisionTreeRegressor(criterion="mse", max_depth=3)

# 学習
model.fit(train_data, train_price)

# 予測（テストデータ）
predict = model.predict(test_data) 

# R2を求める
train_score = model.score(train_data, train_price)
test_score = model.score(test_data, test_price)

print( "\n [ R2 ]" )
print( " 学習データ  : {0:7.5f}".format( train_score ) )
print( " テストデータ: {0:7.5f}".format( test_score ) )

# 散布図の描画
fig = plt.figure()
plt.scatter( test_price , predict )
plt.xlabel("Correct")
plt.ylabel("Predict")
fig.savefig("result.png")

tree.export_graphviz(model, out_file="tree.dot",feature_names=boston.feature_names,filled=True, rounded=True)



