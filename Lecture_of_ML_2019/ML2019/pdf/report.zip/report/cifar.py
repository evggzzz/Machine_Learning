import sys
import os
import numpy as np
import random
from PIL import Image
import matplotlib.pyplot as plt

# クラス数
class_num = 10

# 画像の大きさ
size = 32
feature = size * size * 3

# データ数
DATA = 200

# 学習データ
train_data = np.zeros( (class_num*DATA,feature) , dtype=np.float32 )
train_label = np.zeros( class_num*DATA, dtype=np.int32 )

# テストデータ
test_data = np.zeros( (class_num*DATA,feature) , dtype=np.float32 )
test_label = np.zeros( class_num*DATA, dtype=np.int32 )

# フォルダー名
dir = [ "train" , "test" ]
dir1 = [ "airplane" , "automobile" , "bird" , "cat" , "deer" , "dog" , "frog" , "horse" , "ship" , "truck" ]

# データの読み込み
def Read_data():
    # 学習データの読み込み
    for i in range(class_num):
        for j in range(0,DATA):
            # RGB画像で読み込み
            file = "cifar-10/" + dir[ 0 ] + "/" + dir1[i] + "/" + str(j) + ".png"
            work_img = Image.open(file).convert('RGB')
            
            # 大きさの変換
            resize_img = work_img.resize((size, size))

            # 配列に格納
            train_data[ i * DATA + j ] = np.asarray(resize_img).astype(np.float64).flatten()
            train_label[ i * DATA + j ] = i

    # テストデータの読み込み
    for i in range(class_num):
        for j in range(0,DATA):
            # RGB画像で読み込み
            file = "cifar-10/" + dir[ 1 ] + "/" + dir1[i] + "/" + str(j) + ".png"
            work_img = Image.open(file).convert('RGB')

            # 大きさの変換
            resize_img = work_img.resize((size, size))

            # 配列に格納
            test_data[ i * DATA + j ] = np.asarray(resize_img).astype(np.float64).flatten()
            test_label[ i * DATA + j ] = i

# データの読み込み
Read_data()

# 画像の表示
plt.figure()
rnd = random.randint(0,DATA-1)
count = 1
for i in range(10):
    plt.subplot(2,5,count)
    plt.imshow(np.reshape(train_data[i*DATA+rnd]/255,(size,size,3)))
    plt.xticks(color="None")
    plt.yticks(color="None")
    plt.tick_params(length=0)
    plt.title( dir1[i] )
    count += 1
plt.show()    
plt.close()
