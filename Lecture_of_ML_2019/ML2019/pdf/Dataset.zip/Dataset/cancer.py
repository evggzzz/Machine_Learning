# breast_cancer Dataset
import numpy as np
from sklearn import datasets
from matplotlib import pyplot as plt
import sys

# データのロード
breast_cancer = datasets.load_breast_cancer()

# データの説明
print(breast_cancer.DESCR)

# 特徴量（30次元）
feature_name = breast_cancer.feature_names
print( "\n [ 特徴量 ]" )
print( feature_name )

# 特徴量のデータ
data = breast_cancer.data

# 目的変数
class_name = breast_cancer.target_names
print( "\n [ クラス名 ]" )
print( class_name )

# 目的変数の値
label = breast_cancer.target

# クラスごとのデータ数
label_count = []
for i in range( np.min(label) , np.max(label)+1 ):
    label_count.append( len( label[label==i] ) )
print( "\n [ クラスごとのデータ数 ]" )
print( label_count )

# 特徴量，クラス番号の表示
print( "\n 特徴量           : クラス" ) 
for i in range(len(label)):
    print( data[i] , ":" , label[i] )

# 散布図の表示
for i in range(len(label)-1):
    for j in range(len(label)-1,i,-1):
        if label[j] < label[j-1]:
            work = label[j]
            label[j] = label[j-1]
            label[j-1] = work

            work1 = data[j].copy()
            data[j] = data[j-1].copy()
            data[j-1] = work1.copy()

fig = plt.figure(figsize=(15,15))
plt.subplots_adjust(wspace=0.4, hspace=0.6)
color = [ 'r' , 'g' ]
count = 1
for i in range(5):
    for j in range(5):
        plt.subplot(5,5,count)

        total = 0
        for k in range(2):
            x0 = [d[i] for d in data[total:total+label_count[k]]]
            x1 = [d[j] for d in data[total:total+label_count[k]]]
            plt.scatter(x0, x1,   c=color[k] , label=class_name[k])
            total += label_count[k]
            plt.xlabel(feature_name[i])
            plt.ylabel(feature_name[j])
        count += 1
        #plt.legend()
plt.suptitle("breast_cancer")
plt.show()



