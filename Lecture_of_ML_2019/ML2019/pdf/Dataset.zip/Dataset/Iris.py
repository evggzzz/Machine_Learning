# Iris Dataset
import numpy as np
from sklearn import datasets
from matplotlib import pyplot as plt

# データのロード
iris = datasets.load_iris()

# データの説明
print(iris.DESCR)

# 特徴量（4次元）
feature_name = iris.feature_names
print( "\n [ 特徴量 ]" )
print( feature_name )

# 特徴量のデータ
data = iris.data

# 目的変数( setosa , versicolor , virginica )
class_name = iris.target_names
print( "\n [ クラス名 ]" )
print( class_name )

# 目的変数の値
label = iris.target

# クラスごとのデータ数
label_count = []
for i in range( np.min(label) , np.max(label)+1 ):
    label_count.append( len( label[label==i] ) )

print( "\n [ クラスごとのデータ数 ]" )
print( label_count )

# 特徴量の表示
print( "\n 特徴量           : クラス" ) 
for i in range(len(label)):
    print( data[i] , ":" , label[i] )

# 散布図の表示
fig = plt.figure(figsize=(10,8))
plt.subplots_adjust(wspace=0.4, hspace=0.6)
color = [ 'r' , 'g' , 'b' ]
count = 1
for i in range(4):
    for j in range(4):
        plt.subplot(4,4,count)

        total = 0
        for k in range(3):
            x0 = [d[i] for d in data[total:total+label_count[k]]]
            x1 = [d[j] for d in data[total:total+label_count[k]]]
            plt.scatter(x0, x1,   c=color[k] , label=class_name[k])
            total += label_count[k]
            plt.xlabel(feature_name[i])
            plt.ylabel(feature_name[j])   
        count += 1
        #plt.legend()
plt.suptitle("Iris")
plt.show()



