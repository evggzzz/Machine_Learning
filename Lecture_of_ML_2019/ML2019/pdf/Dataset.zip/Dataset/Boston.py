# boston Dataset
import numpy as np
from sklearn import datasets
from matplotlib import pyplot as plt

# データのロード
boston = datasets.load_boston()

# データの説明
print(boston.DESCR)

# 特徴量（13次元）
feature_name = boston.feature_names
print( "\n [ 特徴量 ]" )
print( feature_name )

# 特徴量のデータ
data = boston.data

# 目的変数
label = boston.target

# 特徴量，目的値の表示
print( "\n 特徴量           : 目的値" ) 
for i in range(len(label)):
    print( data[i] , label[i] )

# 散布図の表示
fig = plt.figure(figsize=(10,8))
plt.subplots_adjust(wspace=0.4, hspace=0.6)

count = 1
for i in range(4):
    for j in range(4):
        plt.subplot(4,4,count)
        
        x0 = data[:,i*4+j]
        x1 = label
        plt.scatter(x0, x1, color='r')
        plt.xlabel(feature_name[i*4+j])
        plt.ylabel("Price")

        if count >= 13:
            break
        count+=1
plt.suptitle('Boston')
plt.show()



