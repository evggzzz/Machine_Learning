# Digits Dataset
import random
import numpy as np
from sklearn import datasets
from matplotlib import pyplot as plt
import sys

# データのロード
digits = datasets.load_digits()

# データの説明
print(digits.DESCR)

# 特徴量 (1797, 8, 8) 
image = digits.images 

# 目的変数
label = digits.target

# 数字ごとのデータ数
print( "\n [ 数字ごとのデータ数 ]" )
for i in range(10):
    print( i , ":" , np.sum(label==i) )

# 平均ベクトル (10,8,8）
ave_image = np.zeros((10,8,8))

# 数字の画像表示
fig1 = plt.figure(figsize=(10,5))
for i in range(10):
    rnd = random.randint(0,len(image))
    plt.subplot(2, 5, i+1)
    plt.title('{0}'.format(label[rnd]))
    plt.imshow(image[rnd],cmap=plt.cm.gray, interpolation='none')

# 平均ベクトルの画像表示
fig2 = plt.figure(figsize=(10,5))
for i in range(10):
    ave_image[i] = image[label==i].mean(axis=0)
    plt.subplot(2, 5, i+1)
    plt.title('{0} ({1})'.format(i, np.sum(label==i)))
    plt.imshow(ave_image[i],cmap=plt.cm.gray, interpolation='none')
plt.show()
