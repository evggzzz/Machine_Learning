# Diabetes Dataset
import numpy as np
from sklearn import datasets
from matplotlib import pyplot as plt

# データのロード
diabetes = datasets.load_diabetes()

# データの説明
print(diabetes.DESCR)

# 特徴量（10次元）
feature_name = diabetes.feature_names
print( "\n [ 特徴量 ]" )
print( feature_name )

# 特徴量のデータ
data = diabetes.data

# 目的変数の値
label = diabetes.target

# 特徴量，目的値の表示
print( "\n 特徴量           : 目的値" ) 
for i in range(len(label)):
    print( data[i] , ":" , label[i] )

# 散布図の表示
fig = plt.figure(figsize=(10,6))
plt.subplots_adjust(wspace=0.4, hspace=0.6)

count = 1
for i in range(3):
    for j in range(4):
        plt.subplot(4,4,count)

        x0 = data[:,i*4+j]
        x1 = label
        plt.scatter(x0, x1, color='r')
        plt.xlabel(feature_name[i*4+j])
        plt.ylabel("Progress")

        if count >= 10:
            break
        count+=1
plt.suptitle('diabetes')
plt.show()



