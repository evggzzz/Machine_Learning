# linnerud Dataset
import numpy as np
from sklearn import datasets
from matplotlib import pyplot as plt
import sys

# データのロード
linnerud = datasets.load_linnerud()

# データの説明
print(linnerud.DESCR)

# 特徴量（3次元）
feature_name = linnerud.feature_names
print( "\n [ 特徴量 ]" )
print( feature_name )

# 特徴量のデータ
data = linnerud.data

# 目的変数
label_name = linnerud.target_names
print( "\n [ クラス名 ]" )
print( label_name )

# 目的変数の値
label = linnerud.target

# 特徴量，目的値の表示
print( "\n 特徴量           : 目的値" ) 
for i in range(len(label)):
    print( data[i] , label[i] )

# 散布図の表示
fig = plt.figure(figsize=(10,8))
plt.subplots_adjust(wspace=0.4, hspace=0.6)
color = [ 'r' , 'g' , 'b' ]

count = 1
for i in range(3):
    for j in range(3):
        plt.subplot(3,3,count)

        x0 = data[:,i]
        x1 = label[:,j]
        plt.scatter(x0, x1, color=color[i])
        plt.xlabel(feature_name[i])
        plt.ylabel(label_name[j])
        plt.title(feature_name[i]+"-"+label_name[j])
        count+=1
plt.suptitle('linnerud')
plt.show()



