# ベイズ決定則
import numpy
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# データのロード
cancer = datasets.load_breast_cancer()

# 種類( malignant, benign )
name = cancer.target_names
label = cancer.target

# 特徴量
feature_names = cancer.feature_names
data = cancer.data

# データ数，特徴量の個数
total , feature_count = data.shape 

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

#model = GaussianNB(priors=None, var_smoothing=1e-9) # バージョン0.19.1では対応していない
model = GaussianNB(priors=None)

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(test_data)
predict_proba = model.predict_proba(test_data)

# 予測結果の表示
print( " malignant benign -> 予測結果 : 正解ラベル" )
for i in range(20):
    print( " {0:5.3f}  {1:5.3f} -> {2:2d} : {3:2d}".format( predict_proba[i][0] , predict_proba[i][1] , predict[i] , test_label[i] ) )

# 事前確率，平均値，分散の表示
for i in range(len(name)):
    print( "\n [ {} ]".format( name[i] ) )
    print( "  事前確率 : {0:.3f}".format( model.class_prior_[i] ) )
    print( "  平均値   :" )
    for j in range(feature_count):
        if j % 10 == 0 and j != 0 : print()
        print( " {0:8.3f}".format( model.theta_[i][j] ) , end="" )
    print( "\n  分散     :" )
    for j in range(feature_count):
        if j % 10 == 0 and j != 0 : print()
        print( " {0:8.3f} ".format( model.sigma_[i][j] ) , end="" )
    print()

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )
