# ロジスティック回帰（交叉検証）
import sys
import numpy as np
from sklearn import datasets
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_validate

# データのロード
cancer = datasets.load_breast_cancer()

# 特徴量（30次元）
feature_names=cancer.feature_names
data = cancer.data

# 目的変数( malignant, benign )
name = cancer.target_names
label = cancer.target

# ロジスティック回帰
model = LogisticRegression(C=1.0,penalty='l2',solver='lbfgs',max_iter=100)

# 交叉検証
score = { "accuracy": "accuracy",
            "precision": "precision_macro",
            "recall": "recall_macro",
            "f":"f1_macro"
            }

result = cross_validate(model, data, label, cv=5, scoring=score,)

# 結果の表示
for i , j in result.items():
    print( " {0:15s} : {1}".format( i , j ) )




