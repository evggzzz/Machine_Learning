# 重回帰分析
import sys
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from matplotlib import pyplot as plt

# データのロード
boston = datasets.load_boston()

# 特徴量（13次元）
feature_name = boston.feature_names
data = boston.data

# 目的変数
label = boston.target
data_count , feature_count = data.shape

# 切片に対応する1の列を挿入
X = np.ones( (data_count,feature_count+1) )
X[:,1:] = data

# ホールドアウト法（学習データ，テストデータ）
train_X, test_X, train_y, test_y = train_test_split(X, label, test_size=0.5, random_state=None)

# 係数の計算
work = np.dot( train_X.T , train_X )
work1 = np.linalg.inv( work )
work2 = np.dot( work1 , train_X.T )
w = np.dot( work2 , train_y )

print(  '\n [ 係数 ]' )
print( w[1:] )
print(  ' [ 切片 ]' )
print( w[0] )

# 予測
predict = np.dot( test_X , w )

# 予測値，正解値
print( '\n [ 予測値  :  正解値 ]' )
for i in range(len(test_y)):
    print( predict[i] , ':' , test_y[i] )

# R2を求める
r = np.corrcoef(test_y, predict)
print( '\n [ R2 ]' )
print( ' テストデータ :' , r[0,1]*r[0,1] )

# 散布図の描画
fig = plt.figure()
plt.scatter( test_y , predict )
plt.xlabel("Correct")
plt.ylabel("Predict")
fig.savefig("result.png")
