# boston Dataset
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn import linear_model
from matplotlib import pyplot as plt

# データのロード
boston = datasets.load_boston()

# 特徴量（13次元）
feature_name = boston.feature_names
data = boston.data

# 目的変数
label = boston.target

# ホールドアウト法（学習データ，テストデータ）
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

model = linear_model.LinearRegression()

# 学習
model.fit( train_data, train_label )

# 係数と切片
print( '\n 係数ベクトル : ' , model.coef_ )
print( ' 切片 : ' , model.intercept_)

# 予測
predict = model.predict(test_data)

# 予測値，正解値
print( '\n [ 予測値  :  正解値 ]' )
for i in range(len(test_label)):
    print( predict[i] , ':' , test_label[i] )

# R2を求める
train_score = model.score(train_data, train_label)
test_score = model.score(test_data, test_label)

print( "\n [ R2 ]" )
print( " 学習データ  : {0:7.5f}".format( train_score ) )
print( " テストデータ: {0:7.5f}".format( test_score ) )

# 散布図の描画
fig = plt.figure()
plt.scatter( test_label , predict )
plt.xlabel("Correct")
plt.ylabel("Predict")
fig.savefig("result.png")
