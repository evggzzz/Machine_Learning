# ロジスティック回帰
import sys
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix, precision_score, recall_score, f1_score
from sklearn.linear_model import LogisticRegression

# データのロード
cancer = datasets.load_breast_cancer()

# 特徴量（30次元）
feature_names=cancer.feature_names
data = cancer.data

# 目的変数( malignant, benign )
name = cancer.target_names
label = cancer.target

# ホールドアウト法（学習データ，テストデータ）
train_data, test_data, train_label, test_label = train_test_split(data, label, test_size=0.5, random_state=None)

# ロジスティック回帰
model = LogisticRegression(C=1.0,penalty='l2',solver='lbfgs',max_iter=100)

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(test_data)

# 係数と切片
print( '\n 係数ベクトル : ' , model.coef_ )
print( ' 切片 : ' , model.intercept_)

# 予測値，教師ラベル
print( '\n [ 予測値  :  教師ラベル ]' )
predict_proba = model.predict_proba(test_data)
for i in range(len(test_label)):
    print( predict_proba[i] , ':' , test_label[i] )
    

# 予測結果の表示
print( "\n [ 予測結果 ]" )
print( ' accuracy  : ' , accuracy_score(test_label, predict) )
print( ' precision : ' , precision_score(test_label, predict) )
print( ' recall    : ' , recall_score(test_label, predict) )
print( ' f1-score  : ' , f1_score(test_label, predict) )

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )


