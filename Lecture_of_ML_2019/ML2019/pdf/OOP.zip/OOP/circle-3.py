import math

class Circle:
    # クラス変数
    DEG = 360

    # コンストラクター
    def __init__( self ):
        self.r = 0 # 半径
        self.l = 0 # 円周
        self.s = 0 # 面積
        self.d = Circle.DEG # 中心角 

    # 半径の設定
    def setRadius( self , r ):
        self.r = r

    # 中心角の設定
    def setDegree( self , d ):
        self.d = d

    # 円周の計算
    def calc_L( self ):
        self.l = 2 * self.r * math.pi * ( self.d / Circle.DEG )

    # 面積の計算
    def calc_S( self ):
        self.s = self.r * self.r * math.pi * ( self.d / Circle.DEG )

    # 表示
    def Print( self ):
        if self.d == 360:
            print( " 半径 {0:.2f}の円の円周は {1:.2f}，面積は {2:.2f}です".format( self.r , self.l , self.s ) )
        else:
            print( " 半径 {0:.2f} 中心角 {1:.2f}の扇形の円弧の長さは {2:.2f}，面積は {3:.2f}です".format( self.r , self.d, self.l , self.s ) )

# コンストラクター
en = Circle()

# 半径の設定
en.setRadius( 20 )

# 中心角の設定
#en.setDegree( 180 )

# 円周の計算
en.calc_L()

# 面積の計算
en.calc_S()

# 表示
en.Print()



