import math

r = 10
l = 2 * math.pi * r
s = r * r * math.pi
print( " 半径 {0:.2f}の円の円周は {1:.2f}，面積は {2:.2f}です".format( r , l , s ) )
