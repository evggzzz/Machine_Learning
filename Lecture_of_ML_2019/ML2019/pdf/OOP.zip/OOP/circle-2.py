import math

class Circle:
    # コンストラクター
    def __init__( self ):
        self.r = 0 # 半径
        self.l = 0 # 円周
        self.s = 0 # 面積

    # 半径の設定
    def setRadius( self , r ):
        self.r = r

    # 円周の計算
    def calc_L( self ):
        self.l = 2 * self.r * math.pi

    # 面積の計算
    def calc_S( self ):
        self.s = self.r * self.r * math.pi

    # 表示
    def Print( self ):
        print( " 半径 {0:.2f}の円の円周は {1:.2f}，面積は {2:.2f}です".format( self.r , self.l , self.s ) )

# コンストラクター
en = Circle()

# 半径の設定
en.setRadius( 20 )

# 円周の計算
en.calc_L()

# 面積の計算
en.calc_S()

# 表示
en.Print()



