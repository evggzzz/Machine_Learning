# k近傍法（digitsデータベース）
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# k近傍法
K = 5

# データのロード
digits = datasets.load_digits()

# 特徴量 (1797, 8, 8) 
image = digits.images
total , x_size , y_size = image.shape 
image = np.reshape( image , [total,x_size*y_size] )

# 目的変数
label = digits.target

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(image, label, test_size=0.5, random_state=None)

model = KNeighborsClassifier(n_neighbors=K, algorithm='kd_tree', metric='minkowski', p=2)

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(test_data)
distance , result = model.kneighbors(test_data,n_neighbors=K)

# K個の候補，距離，予測結果，正解の表示
#for i in range(len(test_data)): # 全て表示していない
for i in range(50):
    for j in range( K ):
        print( "{0:4d}({1})".format(result[i,j],train_label[ result[i,j] ]) , end=" ")
    print( " [ " , end="" )
    for j in range( K ):
        print( "{0:5.2f}".format( distance[i,j] ) , end=" ")
    print( " ] -> {0} [ {1} ]".format( predict[i] , test_label[i] ) )

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )
