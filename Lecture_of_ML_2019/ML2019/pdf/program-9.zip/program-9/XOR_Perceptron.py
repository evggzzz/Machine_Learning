# パーセプトロン（XOR）
import numpy as np
from sklearn.linear_model import Perceptron
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import sys

# 学習データ
train_data = np.array( [[0,1],[1,0],[1,1],[0,0]] )

# 正解ラベル
train_label = np.array( [0,0,1,1] )

# パーセプトロン
model = Perceptron()

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(train_data)
df = model.decision_function(train_data)

# 予測，正解値の表示
for i in range(len(train_data)):
   print( train_data[i][0] , train_data[i][0] , "->" , df[i] , "(", train_label[i] , ")" )

print( "\n [ 予測結果 ]" )
print( classification_report(train_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(train_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(train_label, predict) )
