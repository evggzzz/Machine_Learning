# 階層型ニューラルネットワーク（digitsデータベース）
import numpy as np
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

# データのロード
digits = datasets.load_digits()

# 特徴量 (1797, 8, 8) 
image = digits.images
total , x_size , y_size = image.shape 
image = np.reshape( image , [total,x_size*y_size] )

# 目的変数
label = digits.target

# 学習データ，テストデータ
train_data, test_data, train_label, test_label = train_test_split(image, label, test_size=0.5, random_state=None)

# 階層型ニューラルネットワーク
model = MLPClassifier(hidden_layer_sizes=(32,32),activation='tanh',max_iter=500)

# 学習
model.fit(train_data, train_label)

# 予測
predict = model.predict(test_data)
proba = model.predict_proba(test_data)

# 予測，正解値の表示
#for i in range(len(train_data)):
for i in range(20):
    print( "{0:3d}: ".format( i ) , end="" )
    for j in range(10):
        print( "{0:.2f}  ".format( proba[i][j] ) , end="" )
    print( "( {0} )".format( test_label[i] ) )

print( "\n [ 予測結果 ]" )
print( classification_report(test_label, predict) )

print( "\n [ 正解率 ]" )
print( accuracy_score(test_label, predict) )

print( "\n [ 混同行列 ]" )
print( confusion_matrix(test_label, predict) )
