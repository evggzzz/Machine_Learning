a=[0]*31
for i in range(31):
        a[i]=[1]*31

for y in range(len(a)):
        for x in range(len(a[y])):
                if x == 15 or y == 15:
                        a[y][x]=1
                else:
                        a[y][x]=0
                        
for y in range(len(a)):
        for x in range(len(a[y])):
                if a[y][x]==1:
                        print( "*" , end="" )
                else:
                        print( " " , end="" )
        print()
                       

        
        
