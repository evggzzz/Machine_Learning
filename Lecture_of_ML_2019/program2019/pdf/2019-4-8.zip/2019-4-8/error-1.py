﻿# error-1.py
print(　"Hello!" )
