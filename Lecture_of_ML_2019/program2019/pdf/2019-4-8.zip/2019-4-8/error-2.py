﻿# error-2.py
print( "Hello!”)
