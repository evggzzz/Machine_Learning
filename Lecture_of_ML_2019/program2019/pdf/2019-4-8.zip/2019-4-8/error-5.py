﻿# error-5.py
primt( "Hello!" )
