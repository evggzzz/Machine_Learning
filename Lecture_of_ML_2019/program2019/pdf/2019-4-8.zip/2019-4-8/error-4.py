﻿# error-4.py
print( "Hello!" ]
